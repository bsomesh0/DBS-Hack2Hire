package com.example.Model;

import org.springframework.data.repository.CrudRepository;

import com.example.Services.AppointmentServices;

public interface MyRespository extends CrudRepository<Appointment,Long> {

}
