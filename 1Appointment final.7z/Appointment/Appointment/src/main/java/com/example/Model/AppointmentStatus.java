package com.example.Model;

public enum AppointmentStatus {
	reject,accept,reschedule;

}
