package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import com.example.Model.Appointment;
import com.example.Services.AppointmentServices;

@RestController                
@RequestMapping("v1")
public class AppointmentController {
	
	@Autowired
	AppointmentServices services;
	
	@RequestMapping(path = "/", method = RequestMethod.GET)
    List<Appointment> findAll() {
        return services.findAll();
    }
	
	@RequestMapping(path = "/",method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public Appointment create(@RequestBody Appointment appointment) {
        return services.create(appointment);
    }
	
	@RequestMapping(path = "/{appointmentId}", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
    public Appointment update(@PathVariable Long appointmentId, @RequestBody Appointment appointment) {
        return services.update(appointmentId, appointment);
    }
	@RequestMapping(path = "/{appointmentId}", method = RequestMethod.DELETE)
    void deleteById(@PathVariable Long appointmentId) {
        services.deleteById(appointmentId);
    }

}
