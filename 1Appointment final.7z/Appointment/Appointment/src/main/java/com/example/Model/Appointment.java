package com.example.Model;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

import lombok.Data;

@Data
@Entity
@Table(name="admin")
@EnableAutoConfiguration
public class Appointment {
	
	@Id
	@Column(name="")
	 private int id;
	private String HNI;
	private String WM;
	private 
	
	 
	 
 
}
