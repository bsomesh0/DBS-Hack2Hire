package com.example.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Model.Appointment;
import com.example.Model.MyRespository;

@Service
public class AppointmentServices {

	@Autowired
	MyRespository repo;
	

	
	public List<Appointment> findAll() {
        return (List<Appointment>) repo.findAll();
    }


	public Appointment create(Appointment appointment) {
		return repo.save(appointment);
	}


	public Appointment update(Long appointmentId, Appointment appointment) {
	        return repo.save(appointment);
	    }

	public void deleteById(Long appointmentId) {
        repo.deleteById(appointmentId);
    }
}
